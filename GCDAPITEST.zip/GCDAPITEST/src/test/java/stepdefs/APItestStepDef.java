package stepdefs;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utils.BaseTest;
import utils.Helper;
import utils.ResponseBLOB;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.inject.Inject;

import apiTest.GetCountryData;
import apiTest.UserTest;

public class APItestStepDef {
	ResponseBLOB resp=new ResponseBLOB();
	
	UserTest userTest=new UserTest();

	@When("^call GETPortCall service to validate$")
	public void call_GETPortCall_service_to_validate() throws Throwable {
		userTest.JSONvalidatorforGetPortCallservice("Vijay");
	}
	
	@When("^BOL data is post using post call$")
	public void bol_data_is_post_using_post_call() throws Throwable {
		Thread.sleep(5000);
		userTest.PostService();
		
		
	   
	}
	
	@Then("^call Get Bol service for \"([^\"]*)\" to validate$")
	public void call_Get_Bol_service_for_to_validate(String Event) throws Throwable {
		Thread.sleep(10000);
		userTest.GetServiceCall(Event,"N");
	}
	
	@Then("^call Get Bol service for \"([^\"]*)\" to validate with \"([^\"]*)\"$")
	public void call_Get_Bol_service_for_to_validate_with(String Event,String dqe) throws Throwable {
		Thread.sleep(10000);
		userTest.GetServiceCall(Event,dqe);
	}
	
	@Then("^call Get Bol service to validate$")
	public void call_Get_Bol_service_to_validate() throws Throwable {
		
		Thread.sleep(10000);
		//userTest.GetRequestBilloflading();
		userTest.GetServiceCall("Create","N");
		
	}
	



@When("^call GETComplianceObject service to validate using compliance ID$")
public void call_GETComplianceObject_service_to_validate_using_compliance_ID() throws Throwable {
	//userTest.GetComplianceObjectUsingCmpID();
}

@When("^call GETComplianceObject service to validate using compliance ID for \"([^\"]*)\" and \"([^\"]*)\"$")
public void call_GETComplianceObject_service_to_validate_using_compliance_ID_for_and(String Event, String status) throws Throwable {
	userTest.GetComplianceObjectUsingCmpID(Event, status);
}



@When("^user post BOL request for \"([^\"]*)\" and \"([^\"]*)\"$")
public void user_post_BOL_request_for_and(String Event, String status) throws Throwable {
	userTest.postBOLforEventandStus(Event,status);
	//System.out.println("printed");
}


@When("^user create booking information for \"([^\"]*)\" with \"([^\"]*)\" having \"([^\"]*)\" with \"([^\"]*)\"$")
public void user_create_a_post_body_for_with_having_with(String event, String param, String pramvalue, String dqeApplicable) throws Throwable {

	
	
	if(event.equalsIgnoreCase("CREATE"))
	{
		userTest.updatePostBodyForBol(event, param, pramvalue, dqeApplicable);
	}
	else
	{
		userTest.GetServiceCall("getBOLService",event, dqeApplicable);
		userTest.updatePostBodyForBol(event, param, pramvalue, dqeApplicable);
	}
	
}



@When("^call GETComplianceObject service to validate using compliance ID for \"([^\"]*)\" with \"([^\"]*)\" having \"([^\"]*)\" with \"([^\"]*)\"$")
public void call_GETComplianceObject_service_to_validate_using_compliance_ID_for_with_having_with(String event, String param, String pramvalue, String dqeApplicable) throws Throwable {
	Thread.sleep(5000);
	userTest.GetComplianceObjectUsingCmpID(event, dqeApplicable);
}




@When("^call GETDQEObject service to validate DQE using compliance ID for \"([^\"]*)\" with \"([^\"]*)\" having \"([^\"]*)\" with \"([^\"]*)\"$")
public void call_GETDQEObject_service_to_validate_DQE_using_compliance_ID_for_with_having_with(String event, String param, String pramvalue, String dqeApplicable) throws Throwable {
    userTest.GetDQeObjectUsingCmpID(event, dqeApplicable);
}



@When("^BOL submitted automatically falls in submission timeline for \"([^\"]*)\"$")
public void bol_submitted_automatically_falls_in_submission_timeline_for(String event) throws Throwable {
	
	if(event.contains("Issue_Verify_Copy_of_TPDOC_Closed")&&Helper.country.contains("DKIMP")) {
		Thread.sleep(15000);
		resp.createXMLREsponse();
		resp.UploadToBlob();
	
	}
	else if(event.contains("Issue_Verify_Copy_of_TPDOC_Closed"))
			userTest.checkApprovedStatus(event);
	
}

//Download file from blob
@Then("^download the file$")
public void download_the_file() throws Throwable {
	//resp.DownloadFromBlob();
	resp.UploadToBlobthroughService();
}



@When("^user create booking information for \"([^\"]*)\" with \"([^\"]*)\" ,\"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\"$")
public void user_create_booking_information_for_with(String Event, String operatorcode, String param1, String param1value, String param2, String param2value) throws Throwable {
	
	if(Event.equalsIgnoreCase("CREATE")) {
		
		userTest.updatePostBodyForBolSubmissionCase(Event, operatorcode, param1, param1value,param2,param2value);
	}
	else
	{
		userTest.GetServiceCall("getBOLService",Event,"N");
		userTest.updatePostBodyForBolSubmissionCase(Event, operatorcode, param1, param1value,param2,param2value);
	}
	}

@When("^call GETComplianceObject service to validate using compliance ID for \"([^\"]*)\" with \"([^\"]*)\" ,\"([^\"]*)\" \"([^\"]*)\",\"([^\"]*)\" \"([^\"]*)\"$")
public void call_GETComplianceObject_service_to_validate_using_compliance_ID_for_with(String event, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
	//userTest.GetComplianceObjectUsingCmpID(event, "N");
	userTest.GetServiceCall(event,"N");
}


@When("^user calls get port call service$")
public void user_calls_get_port_call_service() throws Throwable {
    userTest.GetPortCallObject();
}


@When("^user create booking information for \"([^\"]*)\" for \"([^\"]*)\"$")
public void user_create_booking_information_for_for(String event, String type) throws Throwable {
	if(event.equalsIgnoreCase("CREATE"))
		 userTest.createDataASPerScenario(event,type);
	else
	{
		userTest.GetRequestBilloflading();
		 userTest.createDataASPerScenario(event,type);
	}
   
}


@When("^call GETComplianceObject service to validate using compliance ID for \"([^\"]*)\" for \"([^\"]*)\"$")
public void call_GETComplianceObject_service_to_validate_using_compliance_ID_for_for(String event, String arg2) throws Throwable {
	userTest.GetComplianceObjectUsingCmpID(event, "N");
}

// Srinath Code

@When("^user create booking information dangerous booking for \"([^\"]*)\" with \"([^\"]*)\" ,\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\", \"([^\"]*)\"$")
public void user_create_booking_information_for_with(String Event, String operatorcode, String scaccode, String isoog, String containertype, String undgnumber, String param2value) throws Throwable {
	userTest.updatePostBodyDangerousBooking(Event, operatorcode, scaccode, isoog, containertype, undgnumber, param2value);
	
}
@When("^user create booking information dangerous booking for \"([^\"]*)\" with \"([^\"]*)\" ,\"([^\"]*)\"$")
public void user_create_booking_information_for_with(String Event, String operatorcode, String scaccode) throws Throwable {
	userTest.updatePostBodyDangerousBookingCargolines(Event, operatorcode, scaccode);
	
}
@When("^user create booking information dangerous booking for CC \"([^\"]*)\" with \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\"$")
public void user_create_booking_information_for_cc_with(String Event, String operatorcode, String scaccode,String cargomode) throws Throwable {
	userTest.updatePostBodyDangerousBookingCargolinesCC(Event, operatorcode, scaccode,cargomode);
	
}
@When("^user create booking information dangerous booking for BB \"([^\"]*)\" with \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\"$")
public void user_create_booking_information_for__bb_with(String Event, String operatorcode, String scaccode,String cargomode) throws Throwable {
	userTest.updatePostBodyDangerousBookingCargolinesBB(Event, operatorcode, scaccode,cargomode);
	
}

@Then("^call \"([^\"]*)\" for \"([^\"]*)\" to validate with \"([^\"]*)\"$")
public void call_for_to_validate_with(String serviceName, String Event, String dqe) throws Throwable {
  
	Thread.sleep(10000);
	userTest.GetServiceCall(serviceName,Event,dqe);
}



//response upload
@When("^user upload \"([^\"]*)\" response$")
public void user_upload_response(String arg1) throws Throwable {
    
}

@Then("^Verify \"([^\"]*)\" for the manifest for \"([^\"]*)\"$")
public void verify_for_the_manifest_for(String status, String event) throws Throwable {
   if(event.contains("Verify_Copy")&&Helper.country.contains("DKIMP")||Helper.country.contains("DKIMP"))
	   userTest.verifySubmissionStatus();
}

}
