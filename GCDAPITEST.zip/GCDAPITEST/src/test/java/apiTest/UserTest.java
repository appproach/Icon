package apiTest;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;
import static org.testng.Assert.assertEquals;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang3.RandomStringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;

import io.restassured.response.Response;
import pojo.Cargo;
import pojo.User;
import utils.BaseTest;
import utils.Helper;
import utils.Utility;

import com.bbverification.Bbverify;
import com.ccverification.Ccverify;
import com.dangerbookings.Dangerbooking;
import com.dangerouscargolines.Dangerouscargolines;
import com.example.Example;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import GetPortCall.GetPortCallPOJO;
import getDQEcallUsingComplianceId.BillOfLading;
import getDQEcallUsingComplianceId.DQECompliance;

public class UserTest extends BaseTest {

	public String baseUri;

	User bodyload;
	Example GetBol;
	Utility utils;
	public static String bol;
	public static String cmpID;
	public static String GetCookie="ARRAffinity=e6544bf19e630e56176871ae002063ac11fc26dd97b84aa42ebbeab32bc611e2";
	public static String EDI;
	
	
	public String getBOL(String event) {
	if(event.contains("CREATE"))
	{
		String random = RandomStringUtils.randomNumeric(6);
		bol="BOL"+random;
		return bol;
	}
	else
		return bol;
	}
	public void PostService() throws IOException {

		String baseUrlRoute = Helper.propertyReader(Helper.commonFilePath, "baseUrlRoute");
		String baseUriRoute = Helper.propertyReader(Helper.commonFilePath, "baseUriRoute");
	
		Response resp= 
				given()
				.header("Content-Type","application/json").header("Cookie",GetCookie).body(bodyload).
				when()
				.post(baseUrlRoute + baseUriRoute);
		
		if(resp.getStatusCode()!=200)
			Assert.fail("status is not 200 it is : "+resp.getStatusCode());
		
	
}

	public void GetServiceCall(String eventType,String dqeApplicable) throws JsonParseException, JsonMappingException, InterruptedException, IOException {
		
		String URI=Helper.getURI(bol,cmpID);
		System.out.println(URI);
		Response resp =given().header("Cookie",GetCookie).when().get(URI);
		System.out.println(resp.getBody().asString());
		if(resp.getStatusCode()!=200)
			Assert.fail("status in getBOLSErvice is not 200 it is : "+resp.getStatusCode());
		
		if(cmpID!=null)
			JSonvalidatorforGetComplianceObject(resp.getBody().asString(),eventType,dqeApplicable,URI);
		else
			JSONvalidator(resp.getBody().asString());
		
	}	

	
	
	
//Generic method to call getURI	
public void GetServiceCall(String service,String eventType,String dqeApplicable) throws JsonParseException, JsonMappingException, InterruptedException, IOException {
		
		String URI=Helper.getURI(service,bol,cmpID);
		System.out.println(URI);
		Response resp =given().header("Cookie",GetCookie).when().get(URI);
		System.out.println(resp.getBody().asString());
		if(resp.getStatusCode()!=200)
			Assert.fail("status in getBOLSErvice is not 200 it is : "+resp.getStatusCode());
		
		if(service.contains("getComplianceUsingTpdocandBOL"))
			JSonvalidatorforGetComplianceObject(resp.getBody().asString(),eventType,dqeApplicable,URI);
		else
			JSONvalidator(resp.getBody().asString());
		
	}

	
	//@Test(enabled=false,description = "Validate Status code 200 for Bill of Lading  ")
	public void GetRequestBilloflading() throws FileNotFoundException {

		String getBolService = Helper.propertyReader(Helper.commonFilePath, "getBOLService");
		String cookie=Helper.propertyReader(Helper.commonFilePath, "GetCookie");
		System.out.println(getBolService);
		Response resp =given().header("Cookie",cookie).when().get(getBolService+bol);
		System.out.println(resp.getBody().asString());
		if(resp.getStatusCode()!=200)
			Assert.fail("status in getBOLSErvice is not 200 it is : "+resp.getStatusCode());
		JSONvalidator(resp.getBody().asString());
			}

	
	
	
	
	public void GetPortCallObject() throws FileNotFoundException {
			Response resp =given().header("Cookie","ARRAffinity=c9d4dba95981ac6556df1e255f10623d00d4daaacd325bbda9a056ae72099fa0").when().get("https://gcd-port-call.dev.maersk-digital.net/v1/portcall/sites?srcPortCode=FIHELST&destPortCode=DEHAMBK&srcDepartureVoyageCode=1327&destArrivalVoyageCode=1327&vesselCode=5X7");
			
			assertEquals(resp.getStatusCode(),200);
			System.out.println(resp.getBody().asString());
			JSONvalidatorforGetPortCallservice(resp.getBody().asString());
			
		}

	//JSON reader and validator
	public void JSONvalidator(String data)
	{
	      ObjectMapper mapper = new ObjectMapper();
	      try
	      {
	    	    GetBol =  mapper.readValue(data, Example.class);
	    	    
	    	    if(GetBol.getShipments().get(0).getRoute().getRouteLinks().get(0).getCompliances().size()>1)
	    	    {
	    	    	int cmpLenth=GetBol.getShipments().get(0).getRoute().getRouteLinks().get(0).getCompliances().size();
	    	    	for(int i=0;i<cmpLenth;i++)
	    	    	{
	    	    		if(GetBol.getShipments().get(0).getRoute().getRouteLinks().get(0).getCompliances().get(i).startsWith(Helper.country))
	    	    			cmpID =GetBol.getShipments().get(0).getRoute().getRouteLinks().get(0).getCompliances().get(i);
	    	    	}
	    	    }
	    	    else   	    
	    	     cmpID =GetBol.getShipments().get(0).getRoute().getRouteLinks().get(0).getCompliances().get(0);
	    	    GetCountryData.verifyComplianceType(cmpID);

	      } catch (Exception e)
	      {
	         e.printStackTrace();
	      }
		}
	
	
	
	//JSON reader and validator
		public void JSONvalidatorforGetPortCallservice(String data)
		{
			
			GetPortCallPOJO getPortCall[] = null;
		      ObjectMapper mapper = new ObjectMapper();
		      try
		      {
		    	  getPortCall =  mapper.readValue(data, GetPortCallPOJO[].class);
		    	 
		      } catch (Exception e)
		      {
		         e.printStackTrace();
		      }
		      System.out.println("BOL number : "+getPortCall[0].getGsisKey());		      
		      
		}


		public void GetComplianceObjectUsingCmpID(String eventType,String dqeApplicable) throws InterruptedException, JsonParseException, JsonMappingException, IOException {
			String cookie=Helper.propertyReader(Helper.commonFilePath, "GetCookie");
			String getBolService = Helper.propertyReader(Helper.commonFilePath, "getComplianceUsingTpdocandBOL");
			String cmpId =GetBol.getShipments().get(0).getRoute().getRouteLinks().get(0).getCompliances().get(0);
			Helper.loginfo("compliance id: ",cmpId);
			String uri=getBolService+GetBol.getBolNumber()+"&complianceId="+cmpId;
	        Response resp =given().header("Cookie",cookie).when()
	        		.get(uri);
	        System.out.println(resp.getBody().asString());
	        JSonvalidatorforGetComplianceObject(resp.getBody().asString(),eventType,dqeApplicable,uri);
	       
		}
		
		public void JSonvalidatorforGetComplianceObject(String jsonResp,String eventType,String dqeapplicable,String uri) throws InterruptedException, JsonParseException, JsonMappingException, IOException
		{
			
			
			DQECompliance getPortCall = null;
	          ObjectMapper mapper = new ObjectMapper();
	          try
	          {
	        	 getPortCall =  mapper.readValue(jsonResp, DQECompliance.class);
	        	    Helper.loginfo("BOL number on compliance object  ", getPortCall.getBillOfLadings().get(0).getBolNumber());
		  	        Helper.loginfo("compliance ID  ", getPortCall.getComplianceId());
	  	          Helper.loginfo("BOL status : ",getPortCall.getBillOfLadings().get(0).getStatus());
	  	          
	  	       
	          } catch (Exception e)
	          {
	             e.printStackTrace();
	          }
	          
	         
	           if(dqeapplicable.contains("Y"))
	          {
	        	   Thread.sleep(3000);
	        	  System.out.println(getPortCall.getBillOfLadings().get(0).getStatus());
	        	  if(getPortCall.getBillOfLadings().get(0).getStatus().contains("Data Quality Check Failed"))
	        		  assertEquals(getPortCall.getBillOfLadings().get(0).getStatus(), "Data Quality Check Failed");
	        	  else if(getPortCall.getBillOfLadings().get(0).getStatus().contains("Ready For Submission"))
	        		  Assert.fail("Status should be DQE but ready for submission found");
	        	  else {
	        		  int i =0;
	        		  while(i<2) {
	        		  Thread.sleep(25000);
	        		  Response resp2 =given().header("Cookie",GetCookie).when()
	      	        		.get(uri);
	        		  DQECompliance getPortCall1 = null;
	        		  getPortCall1 =  mapper.readValue(resp2.getBody().asString(), DQECompliance.class);
	        		  
	        		 if(getPortCall1.getBillOfLadings().get(0).getStatus().contains("Data Quality Check Failed")) {
	        			 System.out.println("status changed on call no "+i);
	        			 i=3;
	        		 }
	        		 else if(i==1)
	        		     Assert.fail("DQE expected but not found"+i);
	        		 i++;
	        		  }
	        		  
	        	  }
	        			  
	        			
	        	  
	          }
	           else if(dqeapplicable.contains("Approved")&&eventType.equalsIgnoreCase("Issue_Verify_Copy_of_TPDOC_Closed"))
	           {
	        	   Thread.sleep(80000);
	        	   if(getPortCall.getBillOfLadings().get(0).getStatus().equalsIgnoreCase("Approved"))
	        		   System.out.println("DKEXP status changed to approved");
//	        	   else
//	        		   Assert.fail("DKEXP is in "+getPortCall.getBillOfLadings().get(0).getStatus().equalsIgnoreCase("Approved"));
//	        	   
	           }
	           else if(eventType.equalsIgnoreCase("CREATE")||eventType.equalsIgnoreCase("Schedule_Shipment_Closed"))
		          {
	        	   	
		        	  assertEquals(getPortCall.getBillOfLadings().get(0).getStatus(), "Awaiting SI Processing");
		        	  
		          }
	          else {
	        	  	  System.out.println("inside status verification post IVC");
	        		  int itr =0;
	        		  while(itr<2) {
	        		  Thread.sleep(20000);
	        		  Response resp2 =given().header("Cookie",GetCookie).when()
	      	        		.get(uri);
	        		  DQECompliance getPortCall1 = null;
	        		  getPortCall1 =  mapper.readValue(resp2.getBody().asString(), DQECompliance.class);
	        		  
	        		 if(getPortCall1.getBillOfLadings().get(0).getStatus().contains("Ready For Submission")) {
	        			 System.out.println("status changed on call no "+itr);
	        			 itr=3;
	        		 }
	        		 else if(getPortCall1.getBillOfLadings().get(0).getStatus().equalsIgnoreCase("Approved"))
	        			 itr=3;
	        		 else if(getPortCall1.getBillOfLadings().get(0).getStatus().equalsIgnoreCase("Submitted Awaiting Response")) {
	        			 itr=3;
	        			 
	 						EDI=getPortCall1.getBillOfLadings().get(0).getEdiTransmissionId();
	 						System.out.println("EDI value is "+EDI);
	 						}
	        		 else if(itr==1)
	        		     Assert.fail("ready for submission expected but not found");
	        		 itr++;
	        		  }
	        		  
	        	  }
	          }
	           
	           
					
	  	          
	        	 
        
	        	//dqe type needs to be checked
	          
	          
	          
	        
		




		public void postBOLforEventandStus(String eventType, String DQE) throws JsonParseException, JsonMappingException, IOException {
			bol=getBOL(eventType);
			ObjectMapper mapper=new ObjectMapper();
			
			 bodyload = mapper.readValue(new File("C:\\Vijay\\GCD\\Automation\\GCDworkspace\\APITEST\\TestData\\"+"Finland.json"), User.class);
			
			bodyload.getData().setBolNumber(bol);;
			
			bodyload.setKey(bol);
			bodyload.getData().setOperatorCode("MSK");
			
			// event type mapping
			if(eventType.equalsIgnoreCase("CREATE"))
				bodyload.setEventType("CREATE");	     
			else if(eventType.equalsIgnoreCase("Schedule_Shipment_Closed"))
				bodyload.setEventType("Schedule_Shipment_Closed");
			else if(eventType.equalsIgnoreCase("Issue_Verify_Copy_of_TPDOC_Closed"))
				bodyload.setEventType("Issue_Verify_Copy_of_TPDOC_Closed");
			else if(eventType.equalsIgnoreCase("Issue_Amended_Verify_Copy_of_TPDOC_Closed"))
				bodyload.setEventType("Issue_Amended_Verify_Copy_of_TPDOC_Closed");
			
			
			if(DQE.contains("Cleared"))
				System.out.println("No DQE should be raised");
			if(DQE.contains("HS"))
				bodyload.getData().getCargos().get(0).setHsCode("");
			
			String baseUrlRoute = Helper.propertyReader(Helper.commonFilePath, "baseUrlRoute");
			String baseUriRoute = Helper.propertyReader(Helper.commonFilePath, "baseUriRoute");
			Helper.loginfo("Hitting API URL :- ", baseUrlRoute + baseUriRoute);

			Response resp= 
					given()
					.header("Content-Type","application/json").header("Cookie","ARRAffinity=e6544bf19e630e56176871ae002063ac11fc26dd97b84aa42ebbeab32bc611e2").body(bodyload).
					when()
					.post(baseUrlRoute + baseUriRoute);
			assertEquals(resp.getStatusCode(),200);
			System.out.println(resp.getBody().asString());
		}




		public void updatePostBodyForBol(String event, String param, String paramvalue, String dqeApplicable) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, ClassNotFoundException, JsonParseException, JsonMappingException, IOException, InstantiationException, NoSuchFieldException {
			
			bol=getBOL(event);
			Helper.loginfo(event, bol);
			ObjectMapper mapper=new ObjectMapper();
			bodyload = mapper.readValue(new File(Helper.PostCallBOL+"PostCallBody.json"), User.class);
			bodyload=GetCountryData.setCountryspecificData(bodyload);
			bodyload.getData().setBolNumber(bol);
			bodyload.setKey(bol);
			bodyload.setEventType(event);
			String rootEL=getRootElement(param);
			
		if(param!=null) {
			if(rootEL.equalsIgnoreCase("Cargo"))
			{
			// code to add param value in cargo list --- only works for data inside cargo class
				List<Cargo> cargoList = new ArrayList<>();
				Cargo cargo = new Cargo();
				cargo.getClass().getField(param).set(cargo,paramvalue);
				cargoList.add(cargo);
				bodyload.getData().setCargos(cargoList);
			
			}
			else if(rootEL.equalsIgnoreCase("CargoDesc"))
			{
				if(param.contains("Marks"))
					bodyload.getData().getCargos().get(0).getDescriptions().get(0).setCargoDescText(paramvalue);
				else
					bodyload.getData().getCargos().get(0).getDescriptions().get(1).setCargoDescText(paramvalue);
			}
			else if(rootEL.equalsIgnoreCase("CargoPackages"))
			{
				
				bodyload.getData().getCargos().get(0).getCargoPackages().get(0).setPackageStyleAltText(paramvalue);
			}
			else if(rootEL.equalsIgnoreCase("equipments"))
			{
				
			bodyload.getData().getEquipments().get(0).getSeals().get(0).setSealNumber(paramvalue);
			}
			else if(param.equalsIgnoreCase("packageStyleAltText"))
			{
				
			bodyload.getData().getCargos().get(0).getCargoPackages().get(0).setPackageStyleAltText(paramvalue);
			//bodyload.getData().getCargos().get(1).getCargoPackages().get(0).setPackageStyleAltText(paramvalue);
			}
			else if(param.equalsIgnoreCase("packageCount"))
			{
				
			bodyload.getData().getCargos().get(0).getCargoPackages().get(0).setPackageCount(paramvalue);
			}
			else if(param.equalsIgnoreCase("sealNumber"))
			{
				
				bodyload.getData().getEquipments().get(0).getSeals().get(0).setSealName(paramvalue);
			}
			else if(param.equalsIgnoreCase("shipperdocAddress"))
			{
				
			bodyload.getData().getShipments().get(0).getParties().get(0).setDocAddress(paramvalue);
			}
			else if(param.equalsIgnoreCase("ConsigneedocAddress"))
			{
				
				bodyload.getData().getShipments().get(0).getParties().get(1).setDocAddress(paramvalue);
			}
			else if(param.equalsIgnoreCase("SOC"))
			{
				String data[]=paramvalue.split("-");
				bodyload.getData().getCargos().get(0).setCommodityCode(data[0]);
				bodyload.getData().getCargos().get(0).setWeightKgs(data[1]);
				bodyload.getData().getCargos().get(0).getDescriptions().get(1).setCargoDescText(data[2]);
				
			}
			else
				Helper.loginfo("No change required for HS code", bol);
			
			if(dqeApplicable.contains("_TPDOC"))
				bodyload.getData().setIsTransportDocLevelPrinting(true);
			
			System.out.println(bodyload.getData());
		}
		
		//Helper.loginfo("Payload : ",bodyload.getData().toString());
			
		}	
			
			
			
		//this method is to get call for DQE using compliance ID
		public void GetDQeObjectUsingCmpID(String eventType,String dqeApplicable) throws FileNotFoundException {
			 Response resp =given().header("Cookie","ARRAffinity=c9d4dba95981ac6556df1e255f10623d00d4daaacd325bbda9a056ae72099fa0").when().get("https://gcd-compliance-service.azurewebsites.net/v1/compliance/getByComplianceId/SEIMP-TOZ2CHOVRSCVXUKWA56KPA");

	        assertEquals(resp.getStatusCode(),200);
	        System.out.println(resp.getBody().asString());
	        
	        ObjectMapper mapper = new ObjectMapper();
		      try
		      {
		    	  DQECompliance  GetDQEObject =  mapper.readValue(resp.getBody().asString(), DQECompliance.class);
		    	  
		    	  System.out.println(GetDQEObject.getBillOfLadings().size());
		    	  if(dqeApplicable.equalsIgnoreCase("Y")) {
		    	  for (BillOfLading element : GetDQEObject.getBillOfLadings()) {
		    		    
		    		  System.out.println(element.getBolNumber());
		    		  if (element.getBolNumber().equalsIgnoreCase("GCS000110")) {
		    			  System.out.println(element.getDqeErrors().get(0).getDqeType());
		    			  break;
						
					}
		    		}
		    	  }

		      } catch (Exception e)
		      {
		         e.printStackTrace();
		      }
	       
		}
		
		
		
		
		// code to identify root element
		public String getRootElement(String parameter)
		{
			ArrayList<String> Cargos = new ArrayList<String>(
				    Arrays.asList("hsCode", "commodityCode", "commodityDescription"));
			
			ArrayList<String> CargoDesc = new ArrayList<String>(
				    Arrays.asList("cargoDesc", "cargoDescText","Marks and Numbers"));
			
			ArrayList<String> CargoPackages = new ArrayList<String>(
				    Arrays.asList("packageDescriptionType", "packageStyleAltText"));
			
			ArrayList<String> equipments = new ArrayList<String>(
				    Arrays.asList("sealNumber"));
			
			if(Cargos.contains(parameter))
				return "Cargo";
			else if(CargoDesc.contains(parameter))
				return "CargoDesc";
			else if(CargoPackages.contains(parameter))
				return "CargoPackages";
			else if(equipments.contains(parameter))
				return "equipments";
			else
				return "NA";
			
			
			
		}




		public void updatePostBodyForBolSubmissionCase(String Event,String operatorcode,String param1,String param1value,String param2,String param2value) throws JsonParseException, JsonMappingException, IOException {
			bol=getBOL(Event);
			ObjectMapper mapper=new ObjectMapper();
			bodyload = mapper.readValue(new File(Helper.PostCallBOL+"PostCallDKEXP.json"), User.class);
			bodyload=GetCountryData.setCountryspecificData(bodyload);
			bodyload.getData().setBolNumber(bol);;
			bodyload.setKey(bol);
			bodyload.setEventType(Event);
			bodyload.getData().setOperatorCode(operatorcode);
			if(Event.equalsIgnoreCase("SAF"))
				bodyload.getData().setScacCode("SAFM");
			else if(Event.equalsIgnoreCase("SGL"))
				bodyload.getData().setScacCode("SEJJ");
			else if(Event.equalsIgnoreCase("MLL"))
				bodyload.getData().setScacCode("MAEI");
			else if(Event.equalsIgnoreCase("SEA"))
				bodyload.getData().setScacCode("SEAU");
			else
				bodyload.getData().setScacCode("MAEU");
			
			
			if(param1.contains("OOG"))
				bodyload.getData().getCargos().get(1).getEquipmentStuffings().get(0).setIsOOG(param1value);
			else if(param1.contains("containertype"))
				bodyload.getData().getEquipments().get(0).setContainerType(param1value);
			else if(param1.contains("Marks"))
				bodyload.getData().getCargos().get(0).getDescriptions().get(0).setCargoDescText(param1value);
			
			 if(param2.contains("Seal"))
				bodyload.getData().getEquipments().get(0).getSeals().get(0).setSealName(param2value);
			 System.out.println(bodyload.getData());
			
		}




		public void checkApprovedStatus(String event) throws JsonParseException, JsonMappingException, IOException, InterruptedException {
			
			if(event.contains("Verify"))     
	  	        {
				
				String getBolService = Helper.propertyReader(Helper.commonFilePath, "getComplianceUsingTpdocandBOL");
				String uri=getBolService+bol+"&complianceId="+cmpID;
				
					Thread.sleep(35000);
	  				Response resp =given().header("Cookie",GetCookie).when()
	  		        		.get(uri);
	  		        
	  				DQECompliance getPortCall = null;
	  		          ObjectMapper mapper1 = new ObjectMapper();
	  		         
	  		        	    getPortCall =  mapper1.readValue(resp.getBody().asString(), DQECompliance.class);
	  	    		if(getPortCall.getBillOfLadings().get(0).getStatus().equalsIgnoreCase("Approved"))
	  	    			Helper.loginfo("Status changed to ", getPortCall.getBillOfLadings().get(0).getStatus());
	  	    		else
	  	    		  Assert.fail("Status failed");
	  	    	
	  	        }
	  	          

	          }




		public void createDataASPerScenario(String event, String type) throws JsonParseException, JsonMappingException, IOException {
			bol=getBOL(event);
			FileInputStream inFile=null;
			Helper.loginfo(event, bol);
			
			if(type.equalsIgnoreCase("BB"))
				inFile = new FileInputStream(Helper.BrekBulkGDSPath);
			else if(type.equalsIgnoreCase("CC")) 
				inFile = new FileInputStream(Helper.CCBookingGDSPath);
			byte[] str = new byte[inFile.available()];
		     inFile.read(str);
		     String string = new String(str);
		     JSONObject json = createJSONObject(string);
		     System.out.println(json.keySet());
		     
		     JSONObject obj1=replacekeyInJSONObject(json,"bolNumber",bol);
		     JSONObject obj2=replacekeyInJSONObject(obj1,"key",bol);
		     JSONObject obj3=replacekeyInJSONObject(obj2,"eventType",event);
		     String baseUrlRoute = Helper.propertyReader(Helper.commonFilePath, "baseUrlRoute");
				String baseUriRoute = Helper.propertyReader(Helper.commonFilePath, "baseUriRoute");
				String cookie=Helper.propertyReader(Helper.commonFilePath, "GetCookie");
			
				Response resp= 
						given()
						.header("Content-Type","application/json").header("Cookie",cookie).body(bodyload).
						when()
						.post(baseUrlRoute + baseUriRoute);
				
				if(resp.getStatusCode()!=200)
					Assert.fail("status is not 200 it is : "+resp.getStatusCode());
				System.out.println(resp.getBody().asString());
			
			
			
			
		} 
			
		
		private static JSONObject replacekeyInJSONObject(JSONObject jsonObject, String jsonKey,
		        String jsonValue) {

		    for (Object key : jsonObject.keySet()) {
		        if (key.equals(jsonKey) && ((jsonObject.get(key) instanceof String)||(jsonObject.get(key) instanceof Number)||jsonObject.get(key) ==null)) {
		        	jsonObject.put(key, jsonValue);
		            return jsonObject;
		        } else if (jsonObject.get(key) instanceof JSONObject) {
		            JSONObject modifiedJsonobject = (JSONObject) jsonObject.get(key);
		            if (modifiedJsonobject != null) {
		                replacekeyInJSONObject(modifiedJsonobject, jsonKey, jsonValue);
		            }
		        }

		    }
		    return jsonObject;
		}


		private static JSONObject createJSONObject(String jsonString){
		    JSONObject  jsonObject=new JSONObject();
		    JSONParser jsonParser=new  JSONParser();
		    if ((jsonString != null) && !(jsonString.isEmpty())) {
		        try {
		            jsonObject=(JSONObject) jsonParser.parse(jsonString);
		        } catch (org.json.simple.parser.ParseException e) {
		            e.printStackTrace();
		        }
		    }
		    return jsonObject;
		}
		
		
		//Srinath code
		public void updatePostBodyDangerousBooking(String Event, String operatorcode, String scaccode,String isoog,String containertype,
				String undgnumber, String param2value) throws JsonParseException, JsonMappingException, IOException {
			bol=getBOL(Event);
			ObjectMapper mapper = new ObjectMapper();
			Dangerbooking getDangerBooking = null;
			getDangerBooking = mapper.readValue(new File(Helper.PostCallBOL + "Dangerous.json"), Dangerbooking.class);
			getDangerBooking.getData().setBolNumber(bol);
			getDangerBooking.setKey(bol);
			System.out.println("The created Bol number: " + getDangerBooking.getData().getBolNumber());
			getDangerBooking.getData().getShipments().get(0).setShipmentNumber(bol);
			System.out.println("Shipment number has set : "+getDangerBooking.getData().getShipments().get(0).getShipmentNumber());
			getDangerBooking.setEventType(Event);
			getDangerBooking.getData().setOperatorCode(operatorcode);
			System.out.println("The created Operator Code : " + getDangerBooking.getData().getOperatorCode());
			getDangerBooking.getData().setScacCode(scaccode);
			System.out.println("SCAC code"+getDangerBooking.getData().getScacCode());
			getDangerBooking.getData().getShipments().get(0).setIsDangerous(true);
			System.out.println("Dangerous booking is set as True : " +getDangerBooking.getData().getShipments().get(0).getIsDangerous());
			getDangerBooking.getData().getCargos().get(0).getEquipmentStuffings().get(0).setIsOOG(isoog);
			System.out.println("Isoog is set for :  " + getDangerBooking.getData().getCargos().get(0).getEquipmentStuffings().get(0).getIsOOG());
			//getDangerBooking.getData().getCargos().get(0).getDangerousDetails().get(0).setUndgNumber(undgnumber);
			
			System.out.println(" UNDG number is   : "+getDangerBooking.getData().getCargos().get(0).getDangerousDetails().get(0).getUndgNumber());
			
			getDangerBooking.getData().getEquipments().get(0).setContainerType(containertype);
			
		

			Response resp= given().header("Content-Type","application/json").header("Cookie","ARRAffinity=e6544bf19e630e56176871ae002063ac11fc26dd97b84aa42ebbeab32bc611e2").
							body(getDangerBooking).when()
					.post("https://gcd-orchestration.dev.maersk-digital.net/v1/routeEnrichment");
			assertEquals(resp.getStatusCode(),200);
			System.out.println(resp.getBody().asString());
			

		}
		public void updatePostBodyDangerousBookingCargolines(String Event, String operatorcode, String scaccode) throws JsonParseException, JsonMappingException, IOException {
			if (Event.contains("CREATE")) {
				String random = RandomStringUtils.randomNumeric(6);
				bol = "GCD" + random;
			} else
				Helper.loginfo("else call ", bol);

			ObjectMapper mapper = new ObjectMapper();

			Dangerouscargolines getDangerCargolines = null;
			//getPortCall = mapper.readValue(resp.getBody().asString(), Dangerbooking.class);
			
			getDangerCargolines = mapper.readValue(new File(Helper.PostCallBOL+ "Cargolines.json"), Dangerouscargolines.class);

			getDangerCargolines.getData().setBolNumber(bol);
			getDangerCargolines.setKey(bol);
			System.out.println("The created Bol number: " + getDangerCargolines.getData().getBolNumber());
			getDangerCargolines.getData().getShipments().get(0).setShipmentNumber(bol);
			System.out.println("Shipment number has set : "+getDangerCargolines.getData().getShipments().get(0).getShipmentNumber());
			getDangerCargolines.setEventType(Event);
			getDangerCargolines.getData().setOperatorCode(operatorcode);
			System.out.println("The created Operator Code : " + getDangerCargolines.getData().getOperatorCode());
			getDangerCargolines.getData().setScacCode(scaccode);
			System.out.println("SCAC code"+getDangerCargolines.getData().getScacCode());
			getDangerCargolines.getData().getShipments().get(0).setIsDangerous(true);
			System.out.println("Dangerous booking is set as True : " +getDangerCargolines.getData().getShipments().get(0).getIsDangerous());
			
			 

			//System.out.println(getDangerBooking.getData());

			Response resp= given().header("Content-Type","application/json").header("Cookie","ARRAffinity=e6544bf19e630e56176871ae002063ac11fc26dd97b84aa42ebbeab32bc611e2").
							body(getDangerCargolines).when()
					.post("https://gcd-orchestration.dev.maersk-digital.net/v1/routeEnrichment");
			assertEquals(resp.getStatusCode(),200);
			System.out.println(resp.getBody().asString());
			

		}
		public void updatePostBodyDangerousBookingCargolinesCC(String Event, String operatorcode, String scaccode,String cargomode) throws JsonParseException, JsonMappingException, IOException {
			if (Event.contains("CREATE")) {
				String random = RandomStringUtils.randomNumeric(6);
				bol = "GCD" + random;
			} else
				Helper.loginfo("else call ", bol);

			ObjectMapper mapper = new ObjectMapper();

			Ccverify getDangerCCBooking = null;
			//getPortCall = mapper.readValue(resp.getBody().asString(), Dangerbooking.class);
			
			getDangerCCBooking = mapper.readValue(new File("C:\\Users\\srm058\\Desktop\\APITEST\\APITEST\\TestData\\" + "CC_GDS.json"), Ccverify.class);
			
			getDangerCCBooking.getData().setBolNumber(bol);
			getDangerCCBooking.setKey(bol);
			System.out.println("The created Bol number: " + getDangerCCBooking.getData().getBolNumber());
			getDangerCCBooking.getData().getShipments().get(0).setShipmentNumber(bol);
			System.out.println("Shipment number has set : "+getDangerCCBooking.getData().getShipments().get(0).getShipmentNumber());
			getDangerCCBooking.setEventType(Event);
			getDangerCCBooking.getData().setOperatorCode(operatorcode);
			System.out.println("The created Operator Code : " + getDangerCCBooking.getData().getOperatorCode());
			getDangerCCBooking.getData().setScacCode(scaccode);
			System.out.println("SCAC code"+getDangerCCBooking.getData().getScacCode());
			getDangerCCBooking.getData().getShipments().get(0).setIsDangerous(true);
			System.out.println("Dangerous booking is set as True : " +getDangerCCBooking.getData().getShipments().get(0).getIsDangerous());
			getDangerCCBooking.getData().getShipments().get(0).setReceiptCargoMode(cargomode);
			 System.out.println("Cargo Reciept: : "+getDangerCCBooking.getData().getShipments().get(0).getReceiptCargoMode());

			//System.out.println(getDangerBooking.getData());

			Response resp= given().header("Content-Type","application/json").header("Cookie","ARRAffinity=e6544bf19e630e56176871ae002063ac11fc26dd97b84aa42ebbeab32bc611e2").
							body(getDangerCCBooking).when()
					.post("https://gcd-orchestration.dev.maersk-digital.net/v1/routeEnrichment");
			assertEquals(resp.getStatusCode(),200);
			System.out.println(resp.getBody().asString());
			

		}
		public void updatePostBodyDangerousBookingCargolinesBB(String Event, String operatorcode, String scaccode,String cargomode) throws JsonParseException, JsonMappingException, IOException {
			if (Event.contains("CREATE")) {
				String random = RandomStringUtils.randomNumeric(6);
				bol = "GCD" + random;
			} else
				Helper.loginfo("else call ", bol);

			ObjectMapper mapper = new ObjectMapper();

			Bbverify getDangerBBbooking = null;
			//getPortCall = mapper.readValue(resp.getBody().asString(), Dangerbooking.class);
			
			getDangerBBbooking = mapper.readValue(new File("C:\\Users\\srm058\\Desktop\\APITEST\\APITEST\\TestData\\" + "BB_GDS.json"), Bbverify.class);
			
			getDangerBBbooking.getData().setBolNumber(bol);
			getDangerBBbooking.setKey(bol);
			System.out.println("The created Bol number: " + getDangerBBbooking.getData().getBolNumber());
			getDangerBBbooking.getData().getShipments().get(0).setShipmentNumber(bol);
			System.out.println("Shipment number has set : "+getDangerBBbooking.getData().getShipments().get(0).getShipmentNumber());
			getDangerBBbooking.setEventType(Event);
			getDangerBBbooking.getData().setOperatorCode(operatorcode);
			System.out.println("The created Operator Code : " + getDangerBBbooking.getData().getOperatorCode());
			getDangerBBbooking.getData().setScacCode(scaccode);
			System.out.println("SCAC code"+getDangerBBbooking.getData().getScacCode());
			getDangerBBbooking.getData().getShipments().get(0).setIsDangerous(true);
			System.out.println("Dangerous booking is set as True : " +getDangerBBbooking.getData().getShipments().get(0).getIsDangerous());
			getDangerBBbooking.getData().getShipments().get(0).setReceiptCargoMode(cargomode);
			 

			//System.out.println(getDangerBooking.getData());

			Response resp= given().header("Content-Type","application/json").header("Cookie","ARRAffinity=e6544bf19e630e56176871ae002063ac11fc26dd97b84aa42ebbeab32bc611e2").
							body(getDangerBBbooking).when()
					.post("https://gcd-orchestration.dev.maersk-digital.net/v1/routeEnrichment");
			assertEquals(resp.getStatusCode(),200);
			System.out.println(resp.getBody().asString());
			

		}
		public void verifySubmissionStatus() {
			
//			String uri=Helper.getURI("getComplianceUsingTpdocandBOL",bol,cmpID);
//			 ObjectMapper mapper = new ObjectMapper();
//			  Response resp2 =given().header("Cookie",GetCookie).when()
//    	        		.get(uri);
//      		  DQECompliance getPortCall2 = null;
//      		  getPortCall2 =  mapper.readValue(resp2.getBody().asString(), DQECompliance.class);
//      		  
//      		 if(getPortCall2.getBillOfLadings().get(0).getStatus().contains("Ready For Submission")) {
//      			 System.out.println("status changed on call no "+itr);
//      			
//      		 }
//      		 else if(getPortCall2.getBillOfLadings().get(0).getStatus().equalsIgnoreCase("Approved"))
//      			
//      		 else if(getPortCall2.getBillOfLadings().get(0).getStatus().equalsIgnoreCase("Submitted Awaiting Response")) {
//      			 itr=3;
//      			 if(getPortCall2.getBillOfLadings().get(0).getStatus().contains("Submitted Awaiting Response")) {
//						EDI=getPortCall2.getBillOfLadings().get(0).getEdiTransmissionId();
//						System.out.println("EDI value is "+EDI);
//						}
//      		 else if(itr==1)
//      		     Assert.fail("ready for submission expected but not found");
//      		 itr++;
//      		  }
//      		  
//      	  }
//        }
			
			
		}
		
		
		
		
		
		}
		
		
		
		
	
		
			
		
		 
	
