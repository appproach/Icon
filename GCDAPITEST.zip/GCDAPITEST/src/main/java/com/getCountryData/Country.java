package com.getCountryData;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Country
{
	@JsonProperty("Vessel")
    private String Vessel;

	@JsonProperty("EndPointGeoCode")
    private String EndPointGeoCode;

	@JsonProperty("StartPoint")
    private String StartPoint;

	@JsonProperty("EndPoint")
    private String EndPoint;

	@JsonProperty("StartPointGeoCode")
    private String StartPointGeoCode;

	@JsonProperty("Importvoyage")
    private String Importvoyage;

	@JsonProperty("ExportVoyage")
    private String ExportVoyage;
	
    public String getVessel ()
    {
        return Vessel;
    }

    public void setVessel (String Vessel)
    {
        this.Vessel = Vessel;
    }

    public String getEndPointGeoCode ()
    {
        return EndPointGeoCode;
    }

    public void setEndPointGeoCode (String EndPointGeoCode)
    {
        this.EndPointGeoCode = EndPointGeoCode;
    }

    public String getStartPoint ()
    {
        return StartPoint;
    }

    public void setStartPoint (String StartPoint)
    {
        this.StartPoint = StartPoint;
    }

    public String getEndPoint ()
    {
        return EndPoint;
    }

    public void setEndPoint (String EndPoint)
    {
        this.EndPoint = EndPoint;
    }

    public String getStartPointGeoCode ()
    {
        return StartPointGeoCode;
    }

    public String getImportvoyage() {
		return Importvoyage;
	}

	public void setImportvoyage(String importvoyage) {
		Importvoyage = importvoyage;
	}

	public void setStartPointGeoCode (String StartPointGeoCode)
    {
        this.StartPointGeoCode = StartPointGeoCode;
    }

    public String getExportVoyage ()
    {
        return ExportVoyage;
    }

    public void setExportVoyage (String ExportVoyage)
    {
        this.ExportVoyage = ExportVoyage;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Vessel = "+Vessel+", EndPointGeoCode = "+EndPointGeoCode+", StartPoint = "+StartPoint+", EndPoint = "+EndPoint+", StartPointGeoCode = "+StartPointGeoCode+", voyage = "+ExportVoyage+"]";
    }
}
