
package com.dangerbookings;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cargoTypeCode",
    "cargoTypeDescription"
})
public class CargoPackageType {

    @JsonProperty("cargoTypeCode")
    private String cargoTypeCode;
    @JsonProperty("cargoTypeDescription")
    private String cargoTypeDescription;

    @JsonProperty("cargoTypeCode")
    public String getCargoTypeCode() {
        return cargoTypeCode;
    }

    @JsonProperty("cargoTypeCode")
    public void setCargoTypeCode(String cargoTypeCode) {
        this.cargoTypeCode = cargoTypeCode;
    }

    @JsonProperty("cargoTypeDescription")
    public String getCargoTypeDescription() {
        return cargoTypeDescription;
    }

    @JsonProperty("cargoTypeDescription")
    public void setCargoTypeDescription(String cargoTypeDescription) {
        this.cargoTypeDescription = cargoTypeDescription;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("cargoTypeCode", cargoTypeCode).append("cargoTypeDescription", cargoTypeDescription).toString();
    }

}
