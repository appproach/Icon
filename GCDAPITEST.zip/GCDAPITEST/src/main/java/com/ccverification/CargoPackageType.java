
package com.ccverification;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cargoTypeCode",
    "cargoTypeDescription"
})
public class CargoPackageType {

    @JsonProperty("cargoTypeCode")
    private String cargoTypeCode;
    @JsonProperty("cargoTypeDescription")
    private String cargoTypeDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cargoTypeCode")
    public String getCargoTypeCode() {
        return cargoTypeCode;
    }

    @JsonProperty("cargoTypeCode")
    public void setCargoTypeCode(String cargoTypeCode) {
        this.cargoTypeCode = cargoTypeCode;
    }

    @JsonProperty("cargoTypeDescription")
    public String getCargoTypeDescription() {
        return cargoTypeDescription;
    }

    @JsonProperty("cargoTypeDescription")
    public void setCargoTypeDescription(String cargoTypeDescription) {
        this.cargoTypeDescription = cargoTypeDescription;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("cargoTypeCode", cargoTypeCode).append("cargoTypeDescription", cargoTypeDescription).append("additionalProperties", additionalProperties).toString();
    }

}
