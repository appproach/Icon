
package com.dangerouscpmstatus;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "complianceId",
    "brand",
    "complianceType",
    "complianceName",
    "createdDate",
    "updatedDate",
    "lastSubmittedDate",
    "compliancePort",
    "status",
    "messageReference",
    "receiversReferenceNumber",
    "receiversReferenceDate",
    "mandatoryFields",
    "exportComplianceRefVDN",
    "refVDN",
    "billOfLadings"
})
public class Getcmpstatus {

    @JsonProperty("complianceId")
    private String complianceId;
    @JsonProperty("brand")
    private String brand;
    @JsonProperty("complianceType")
    private String complianceType;
    @JsonProperty("complianceName")
    private String complianceName;
    @JsonProperty("createdDate")
    private String createdDate;
    @JsonProperty("updatedDate")
    private String updatedDate;
    @JsonProperty("lastSubmittedDate")
    private String lastSubmittedDate;
    @JsonProperty("compliancePort")
    private String compliancePort;
    @JsonProperty("status")
    private String status;
    @JsonProperty("messageReference")
    private String messageReference;
    @JsonProperty("receiversReferenceNumber")
    private Object receiversReferenceNumber;
    @JsonProperty("receiversReferenceDate")
    private Object receiversReferenceDate;
    @JsonProperty("mandatoryFields")
    private Object mandatoryFields;
    @JsonProperty("exportComplianceRefVDN")
    private Object exportComplianceRefVDN;
    @JsonProperty("refVDN")
    private Object refVDN;
    @JsonProperty("billOfLadings")
    private List<BillOfLading> billOfLadings = null;

    @JsonProperty("complianceId")
    public String getComplianceId() {
        return complianceId;
    }

    @JsonProperty("complianceId")
    public void setComplianceId(String complianceId) {
        this.complianceId = complianceId;
    }

    @JsonProperty("brand")
    public String getBrand() {
        return brand;
    }

    @JsonProperty("brand")
    public void setBrand(String brand) {
        this.brand = brand;
    }

    @JsonProperty("complianceType")
    public String getComplianceType() {
        return complianceType;
    }

    @JsonProperty("complianceType")
    public void setComplianceType(String complianceType) {
        this.complianceType = complianceType;
    }

    @JsonProperty("complianceName")
    public String getComplianceName() {
        return complianceName;
    }

    @JsonProperty("complianceName")
    public void setComplianceName(String complianceName) {
        this.complianceName = complianceName;
    }

    @JsonProperty("createdDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("createdDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("updatedDate")
    public String getUpdatedDate() {
        return updatedDate;
    }

    @JsonProperty("updatedDate")
    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    @JsonProperty("lastSubmittedDate")
    public String getLastSubmittedDate() {
        return lastSubmittedDate;
    }

    @JsonProperty("lastSubmittedDate")
    public void setLastSubmittedDate(String lastSubmittedDate) {
        this.lastSubmittedDate = lastSubmittedDate;
    }

    @JsonProperty("compliancePort")
    public String getCompliancePort() {
        return compliancePort;
    }

    @JsonProperty("compliancePort")
    public void setCompliancePort(String compliancePort) {
        this.compliancePort = compliancePort;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("messageReference")
    public String getMessageReference() {
        return messageReference;
    }

    @JsonProperty("messageReference")
    public void setMessageReference(String messageReference) {
        this.messageReference = messageReference;
    }

    @JsonProperty("receiversReferenceNumber")
    public Object getReceiversReferenceNumber() {
        return receiversReferenceNumber;
    }

    @JsonProperty("receiversReferenceNumber")
    public void setReceiversReferenceNumber(Object receiversReferenceNumber) {
        this.receiversReferenceNumber = receiversReferenceNumber;
    }

    @JsonProperty("receiversReferenceDate")
    public Object getReceiversReferenceDate() {
        return receiversReferenceDate;
    }

    @JsonProperty("receiversReferenceDate")
    public void setReceiversReferenceDate(Object receiversReferenceDate) {
        this.receiversReferenceDate = receiversReferenceDate;
    }

    @JsonProperty("mandatoryFields")
    public Object getMandatoryFields() {
        return mandatoryFields;
    }

    @JsonProperty("mandatoryFields")
    public void setMandatoryFields(Object mandatoryFields) {
        this.mandatoryFields = mandatoryFields;
    }

    @JsonProperty("exportComplianceRefVDN")
    public Object getExportComplianceRefVDN() {
        return exportComplianceRefVDN;
    }

    @JsonProperty("exportComplianceRefVDN")
    public void setExportComplianceRefVDN(Object exportComplianceRefVDN) {
        this.exportComplianceRefVDN = exportComplianceRefVDN;
    }

    @JsonProperty("refVDN")
    public Object getRefVDN() {
        return refVDN;
    }

    @JsonProperty("refVDN")
    public void setRefVDN(Object refVDN) {
        this.refVDN = refVDN;
    }

    @JsonProperty("billOfLadings")
    public List<BillOfLading> getBillOfLadings() {
        return billOfLadings;
    }

    @JsonProperty("billOfLadings")
    public void setBillOfLadings(List<BillOfLading> billOfLadings) {
        this.billOfLadings = billOfLadings;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("complianceId", complianceId).append("brand", brand).append("complianceType", complianceType).append("complianceName", complianceName).append("createdDate", createdDate).append("updatedDate", updatedDate).append("lastSubmittedDate", lastSubmittedDate).append("compliancePort", compliancePort).append("status", status).append("messageReference", messageReference).append("receiversReferenceNumber", receiversReferenceNumber).append("receiversReferenceDate", receiversReferenceDate).append("mandatoryFields", mandatoryFields).append("exportComplianceRefVDN", exportComplianceRefVDN).append("refVDN", refVDN).append("billOfLadings", billOfLadings).toString();
    }

}
