
package com.dangerouscargolines;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "instanceId",
    "undgNumber",
    "dangGoodsCode",
    "contactPerson",
    "phoneNumber",
    "isFinestLevel",
    "flashPointC",
    "dngClass",
    "packageCount",
    "packageStyleAltText",
    "weightGrossKgs",
    "weightNetKgs"
})
public class DangerousDetail {

    @JsonProperty("instanceId")
    private String instanceId;
    @JsonProperty("undgNumber")
    private String undgNumber;
    @JsonProperty("dangGoodsCode")
    private String dangGoodsCode;
    @JsonProperty("contactPerson")
    private String contactPerson;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("isFinestLevel")
    private String isFinestLevel;
    @JsonProperty("flashPointC")
    private String flashPointC;
    @JsonProperty("dngClass")
    private String dngClass;
    @JsonProperty("packageCount")
    private String packageCount;
    @JsonProperty("packageStyleAltText")
    private String packageStyleAltText;
    @JsonProperty("weightGrossKgs")
    private String weightGrossKgs;
    @JsonProperty("weightNetKgs")
    private String weightNetKgs;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("instanceId")
    public String getInstanceId() {
        return instanceId;
    }

    @JsonProperty("instanceId")
    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    @JsonProperty("undgNumber")
    public String getUndgNumber() {
        return undgNumber;
    }

    @JsonProperty("undgNumber")
    public void setUndgNumber(String undgNumber) {
        this.undgNumber = undgNumber;
    }

    @JsonProperty("dangGoodsCode")
    public String getDangGoodsCode() {
        return dangGoodsCode;
    }

    @JsonProperty("dangGoodsCode")
    public void setDangGoodsCode(String dangGoodsCode) {
        this.dangGoodsCode = dangGoodsCode;
    }

    @JsonProperty("contactPerson")
    public String getContactPerson() {
        return contactPerson;
    }

    @JsonProperty("contactPerson")
    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @JsonProperty("isFinestLevel")
    public String getIsFinestLevel() {
        return isFinestLevel;
    }

    @JsonProperty("isFinestLevel")
    public void setIsFinestLevel(String isFinestLevel) {
        this.isFinestLevel = isFinestLevel;
    }

    @JsonProperty("flashPointC")
    public String getFlashPointC() {
        return flashPointC;
    }

    @JsonProperty("flashPointC")
    public void setFlashPointC(String flashPointC) {
        this.flashPointC = flashPointC;
    }

    @JsonProperty("dngClass")
    public String getDngClass() {
        return dngClass;
    }

    @JsonProperty("dngClass")
    public void setDngClass(String dngClass) {
        this.dngClass = dngClass;
    }

    @JsonProperty("packageCount")
    public String getPackageCount() {
        return packageCount;
    }

    @JsonProperty("packageCount")
    public void setPackageCount(String packageCount) {
        this.packageCount = packageCount;
    }

    @JsonProperty("packageStyleAltText")
    public String getPackageStyleAltText() {
        return packageStyleAltText;
    }

    @JsonProperty("packageStyleAltText")
    public void setPackageStyleAltText(String packageStyleAltText) {
        this.packageStyleAltText = packageStyleAltText;
    }

    @JsonProperty("weightGrossKgs")
    public String getWeightGrossKgs() {
        return weightGrossKgs;
    }

    @JsonProperty("weightGrossKgs")
    public void setWeightGrossKgs(String weightGrossKgs) {
        this.weightGrossKgs = weightGrossKgs;
    }

    @JsonProperty("weightNetKgs")
    public String getWeightNetKgs() {
        return weightNetKgs;
    }

    @JsonProperty("weightNetKgs")
    public void setWeightNetKgs(String weightNetKgs) {
        this.weightNetKgs = weightNetKgs;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("instanceId", instanceId).append("undgNumber", undgNumber).append("dangGoodsCode", dangGoodsCode).append("contactPerson", contactPerson).append("phoneNumber", phoneNumber).append("isFinestLevel", isFinestLevel).append("flashPointC", flashPointC).append("dngClass", dngClass).append("packageCount", packageCount).append("packageStyleAltText", packageStyleAltText).append("weightGrossKgs", weightGrossKgs).append("weightNetKgs", weightNetKgs).append("additionalProperties", additionalProperties).toString();
    }

}
