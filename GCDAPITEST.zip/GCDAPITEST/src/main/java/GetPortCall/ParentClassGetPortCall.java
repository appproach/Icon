package GetPortCall;

import java.util.List;

public class ParentClassGetPortCall {
	
	private List<GetPortCallPOJO> GetPortCallPOJO;

	public List<GetPortCallPOJO> getGetPortCallPOJO() {
		return GetPortCallPOJO;
	}

	public void setGetPortCallPOJO(List<GetPortCallPOJO> getPortCallPOJO) {
		GetPortCallPOJO = getPortCallPOJO;
	}

}
